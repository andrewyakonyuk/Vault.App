﻿/// <autosync enabled="true" />
/// <reference path="../gulpfile.js" />
/// <reference path="app/app-bundle.min.js" />
/// <reference path="app/modules/views/app.js" />
/// <reference path="app/modules/views/board.js" />
/// <reference path="app/modules/views/sidebar.js" />
/// <reference path="app/plugins/jquery.infinity.js" />
/// <reference path="app/plugins/jquery.sticky.js" />
/// <reference path="app/plugins/mpmenu.js" />
/// <reference path="app/startup.js" />
/// <reference path="app/widgets/audio.js" />
/// <reference path="bower_modules/backbone/backbone.js" />
/// <reference path="bower_modules/bootstrap/dist/js/bootstrap.js" />
/// <reference path="bower_modules/hammerjs/hammer.js" />
/// <reference path="bower_modules/jquery/dist/jquery.js" />
/// <reference path="bower_modules/jquery-pjax/jquery.pjax.js" />
/// <reference path="bower_modules/jquery-ui/jquery-ui.js" />
/// <reference path="bower_modules/jquery-validation-unobtrusive/jquery.validate.unobtrusive.js" />
/// <reference path="bower_modules/pace/pace.js" />
/// <reference path="bower_modules/requirejs/require.js" />
/// <reference path="bower_modules/underscore/underscore.js" />
/// <reference path="require.config.js" />


